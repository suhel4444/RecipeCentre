var ejs = require("ejs");
var mysql = require('./mysql');



function submitRequest(req,res)
{
	var insertUser="insert into request (type, name, size) values ( '"+req.param("type")
					+"' ,'" + req.param("name") +"','" + req.param("size") +"')";
	
	console.log("Query is:"+insertUser);
	
	mysql.insertData(insertUser);
	res.render('success');
	
}

exports.submitRequest=submitRequest;


function registeredUser(req,res)
{
	
	res.render('request');
	
}

exports.registeredUser=registeredUser;