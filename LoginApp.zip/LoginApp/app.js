
/**
 * Module dependencies.
 */

var session = require('client-sessions'); 

var express = require('express')
  , routes = require('./routes')
  , user = require('./routes/user')
  , http = require('http')
  , path = require('path');

global.app = express();

app.use(session({
  cookieName: 'session',
  secret: 'random_string_goes_here',
  duration: 30 * 60 * 1000,
  activeDuration: 5 * 60 * 1000,
}));




// all environments
app.set('port', process.env.PORT || 3005);
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');
app.use(express.bodyParser());
app.use(express.favicon());
app.use(express.logger('dev'));

app.use(express.methodOverride());
app.use(app.router);
app.use(express.static(path.join(__dirname, 'public')));

// development only
if ('development' == app.get('env')) {
  app.use(express.errorHandler());
}



var login=require('./routes/login');
var signup=require('./routes/signup');
var request= require('./routes/request');
var community= require('./routes/community');
var retrieve= require('./routes/retrieve');

app.get('/', routes.index);

app.post('/', routes.index);
app.post('/signin', login.signIn);
app.get('/request', request.registeredUser);
app.get('/communityPage', community.community);
app.get('/showRequest', request.showRequest);
app.get('/showAllRequests', request.showAllRequests);

app.post('/submitRequest', request.submitRequest);



//app.post('/registeredUser', request.registeredUser);
app.post('/signup', signup.signup);
app.post('/newuser', signup.newUser);
app.post('/listuser', login.getAllUsers);
app.post('/createCommunity', community.createCommunity);

app.get('/retrieve', retrieve.retrieve);

http.createServer(app).listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
});
