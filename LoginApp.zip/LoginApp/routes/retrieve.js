var ejs = require("ejs");
var mysql = require('./mysql');


function retrieve(req,res)
{
	// check user already exists
	var getUser="select firstname, email, phno from users where role='moderator'";
	console.log("Query is:"+getUser);
	
	mysql.fetchData(function(err, results){
		if(err){
			throw err;
		}
		else 
		{
		res.send(results);
	}
			
	},getUser);
	
	

}

exports.retrieve=retrieve;