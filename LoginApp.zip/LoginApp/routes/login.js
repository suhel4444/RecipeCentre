var ejs = require("ejs");
var mysql = require('./mysql');


function signIn(req,res)
{
	// check user already exists
	var getUser="select * from users where username='"+req.param("username")+"' and password='" + req.param("pwd") +"'";
	console.log("Query is:"+getUser);
	
	mysql.fetchData(function(err,results){
		if(err){
			throw err;
		}
		else 
		{
			if(results.length > 0){
				console.log("valid Login");
				req.session.user = results[0];
				console.log("Test",results);
				//console.log(req.session);
				global.app.use(function(req, res, next) {
					  res.locals.user = req.session.user;
					  next();
					});

				console.log("test:"+results.role);
				if(results[0].role == "moderator")
				{


					var getRequests = "select * from request where username='"+req.param("username")+"' and password='" + req.param("pwd") +"'";





					ejs.renderFile('./views/success.ejs', { data: results, heading:"User Details" } , function(err, result) {
					        // render on success
					        if (!err) {
					            res.end(result);
					        }
					        // render or error
					        else {
					            res.end('An error occurred');
					            console.log(err);
					        }
			   		 });


				}
				else
				{
					console.log("admin");
					ejs.renderFile('./views/successAdmin.ejs', { data: results, heading:"User Details" } , function(err, result) {
					        // render on success
					        if (!err) {
					            res.end(result);
					        }
					        // render or error
					        else {
					            res.end('An error occurred');
					            console.log(err);
					        }
			   		 });




				}

				
			}
			else {    
				
				console.log("Invalid Login");
				ejs.renderFile('./views/error.ejs',function(err, result) {
			        // render on success
			        if (!err) {
			            res.end(result);
			        }
			        // render or error
			        else {
			            res.end('An error occurred');
			            console.log(err);
			        }
			    });
			}
		}  
	},getUser);
	
	
}

function getAllUsers(req,res)
{
	var getAllUsers = "select * from users";
	console.log("Query is:"+getAllUsers);
	
	mysql.fetchData(function(err,results){
		if(err){
			throw err;
		}
		else 
		{
			if(results.length > 0){
				
				var rows = results;
				var jsonString = JSON.stringify(results);
				var jsonParse = JSON.parse(jsonString);
				
				console.log("Results Type: "+(typeof results));
				console.log("Result Element Type:"+(typeof rows[0].emailid));
				console.log("Results Stringify Type:"+(typeof jsonString));
				console.log("Results Parse Type:"+(typeof jsString));
				
				console.log("Results: "+(results));
				console.log("Result Element:"+(rows[0].emailid));
				console.log("Results Stringify:"+(jsonString));
				console.log("Results Parse:"+(jsonParse));
				
				ejs.renderFile('./views/success.ejs',{data:rows, heading:"User List"},function(err, result) {
			        // render on success
			        if (!err) {
			            res.end(result);
			        }
			        // render or error
			        else {
			            res.end('An error occurred');
			            console.log(err);
			        }
			    });
			}
			else {    
				
				console.log("No users found in database");
				ejs.renderFile('./views/error.ejs',function(err, result) {
			        // render on success
			        if (!err) {
			            res.end(result);
			        }
			        // render or error
			        else {
			            res.end('An error occurred');
			            console.log(err);
			        }
			    });
			}
		}  
	},getAllUsers);
}

exports.signIn=signIn;
exports.getAllUsers=getAllUsers;