var ejs = require("ejs");
var mysql = require('./mysql');



function submitRequest(req,res)
{
	var insertUser="insert into request (name, description,requestor ,status,size, purpose) values ( '"+req.param("name")
					+"' ,'" + req.param("description")+"','" + req.session.user.username +"','Pending','" + req.param("size")+"' ,'"+ req.param("purpose")+"')";
	
	console.log("Query is:"+insertUser);
	
	mysql.insertData(insertUser);

	var getRequest = "select * from request where requestor='"+req.session.user.username+"'";


	mysql.fetchData(function(err,results){
		if(err){
			throw err;
		}
		else 
		{
			console.log("REs"+results);
			ejs.renderFile('./views/showRequest.ejs', { data: results, heading:"Request Details" } , function(err, result) {
					        // render on success
					        if (!err) {
					            res.end(result);
					        }
					        // render or error
					        else {
					            res.end('An error occurred');
					            console.log(err);
					        }
			   		 });


		}


	}, getRequest);
	
	
}

exports.submitRequest=submitRequest;


function registeredUser(req,res)
{
	
	res.render('request');
	
}

exports.registeredUser=registeredUser;

function showRequest(req,res)
{
	
	var getRequest = "select * from request where requestor='"+req.session.user.username+"'";


	mysql.fetchData(function(err,results){
		if(err){
			throw err;
		}
		else 
		{
			console.log("REs"+results);
			ejs.renderFile('./views/showRequest.ejs', { data: results, heading:"Request Details" } , function(err, result) {
					        // render on success
					        if (!err) {
					            res.end(result);
					        }
					        // render or error
					        else {
					            res.end('An error occurred');
					            console.log(err);
					        }
			   		 });


		}


	}, getRequest);
	
	
	
}

exports.showRequest=showRequest;


function showAllRequests(req,res)
{
   
   var getRequest = "select * from request order by requestID";


   mysql.fetchData(function(err,results){
       if(err){
           throw err;
       }
       else
       {
           console.log("REs"+results);
           ejs.renderFile('./views/seeAllRequests.ejs', { data: results, heading:"Request Details" } , function(err, result) {
                           // render on success
                           if (!err) {
                               res.end(result);
                           }
                           // render or error
                           else {
                               res.end('An error occurred');
                               console.log(err);
                           }
                       });


       }


   }, getRequest);
   
   
   
}

exports.showAllRequests=showAllRequests;