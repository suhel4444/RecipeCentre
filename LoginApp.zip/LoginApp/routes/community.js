var ejs = require("ejs");
var mysql = require('./mysql');



function createCommunity(req,res)
{
	
		global.req=req;
		global.res=res;

		// Load the AWS SDK for Node.js
		var AWS = require('aws-sdk');

		// Set the region 
		AWS.config.update({region: 'us-west-2'});

		// Create EC2 service object
		var ec2 = new AWS.EC2({apiVersion: '2016-11-15'});


		var params = {
		   ImageId: 'ami-51855629',
		   InstanceType: 't2.micro',
		   MinCount: 1,
		   MaxCount: 1,
		   KeyName: 'mykey'
		};

		// Create the instance
		ec2.runInstances(params, function(err, data) {
			   if (err) {
			      console.log("Could not create instance", err);
			      return;
			   }

			   var instanceId = data.Instances[0].InstanceId;


			   params = {
				
			    InstanceIds: [instanceId]
			   };


				ec2.waitFor('instanceRunning', params, function(err, data) 
				{
					  if (err) 
					  console.log(err, err.stack); // an error occurred
					  else
					  {
					  	
					  		console.log(JSON.stringify(data));
					  		var ip= data.Reservations[0].Instances[0].PublicIpAddress
					  		console.log("check :"+ip);
					  		var commName="Police Department";
					  		var requestor="suhel123";

					  		var insertUser="insert into communitydetail (communityname, ipaddress, moderator, notification_sent) values ( '"+commName
					+"' ,'" + ip +"','" + requestor +"','Pending')";
	
							console.log("Query is:"+insertUser);
							
							mysql.insertData(insertUser);


							var getRequest = "select * from communitydetail cd, users u where cd.moderator=u.username and cd.moderator='"+requestor+"' order by cd.communityid desc";


							mysql.fetchData(function(err,results){
								if(err){
									throw err;
								}
								else 
								{
									console.log("REs"+results);
									ejs.renderFile('./views/CommunityDetails.ejs', { data: results, heading:"Request Details" } , function(err, result) {
											        // render on success
											        if (!err) {
											            global.res.end(result);
											        }
											        // render or error
											        else {
											            global.res.end('An error occurred');
											            console.log(err);
											        }
									   		 });


								}


							}, getRequest);

			
					  }          
				});


		 });




	// var insertUser="insert into request (type, name, size) values ( '"+req.param("type")
	// 				+"' ,'" + req.param("name") +"','" + req.param("size") +"')";
	
	// console.log("Query is:"+insertUser);
	
	// mysql.insertData(insertUser);
	 
	
}

exports.createCommunity=createCommunity;


function community(req,res)
{
	
	res.render('createCommunity');
	
}

exports.community=community;