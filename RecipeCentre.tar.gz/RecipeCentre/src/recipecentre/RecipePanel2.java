
package recipecentre;


public class RecipePanel2 extends javax.swing.JPanel {


    public RecipePanel2() {
        initComponents();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lb1 = new javax.swing.JLabel();
        lb2 = new javax.swing.JLabel();

        setBackground(java.awt.Color.white);
        setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        setLayout(null);

        lb1.setText("Image");
        lb1.setBorder(new javax.swing.border.MatteBorder(null));
        add(lb1);
        lb1.setBounds(30, 20, 150, 100);

        lb2.setFont(new java.awt.Font("SansSerif", 3, 15)); // NOI18N
        lb2.setText("Title");
        lb2.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        add(lb2);
        lb2.setBounds(30, 130, 190, 70);
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JLabel lb1;
    public javax.swing.JLabel lb2;
    // End of variables declaration//GEN-END:variables
}
