package recipecentre;
public class Credentials {
  public static String f2f_Api_key="6584401f39664108f8f9db0f83550b19";  
}
