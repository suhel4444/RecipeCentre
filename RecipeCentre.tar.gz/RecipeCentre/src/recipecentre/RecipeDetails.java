package recipecentre;

import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.Socket;
import java.net.URI;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class RecipeDetails extends javax.swing.JFrame {

    int w, h;
    String title, image_url, procedure, indeg = "";
    String rId, source_url, inputLine, s = "";

    public RecipeDetails(String t, String im, String rId) {
        this.setLayout(null);
        this.setTitle("RecipeDetails");
        initComponents();
        this.title = t;
        this.image_url = im;
        this.rId = rId;
        bt_offline.setEnabled(false);
        //Code to resize the frame compatible to screen size.
        Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
        int w = (int) d.getWidth();
        int h = (int) d.getHeight();
        this.setSize(w, h);

        File f = new File("favorites.txt");
        if (f.exists()) {
            try {
                FileInputStream fis = new FileInputStream(f);
                BufferedReader br = new BufferedReader(new InputStreamReader(fis));
                while (true) {

                    inputLine = br.readLine();
                    if (inputLine == null) {
                        break;
                    }
                    s = s + inputLine;
                }
                if (s.contains("~" + rId + "~")) {
                    bt_like.setVisible(false);
                    bt_unlike.setVisible(true);
                }
                fis.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }

        } else {
            bt_like.setVisible(true);
            bt_unlike.setVisible(false);
        }

        jl_title.setText(this.title);
        new Thread(new Runnable() {
            public void run() {
                try {
                    URL url_rd = new URL(image_url);
                    HttpURLConnection conn_rd = (HttpURLConnection) url_rd.openConnection();

                    conn_rd.setRequestProperty("User-Agent", "Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.4; en-US; rv:1.9.2.2) Gecko/20100316 Firefox/3.6.2");
                    Image image_rd = null;
                    image_rd = ImageIO.read(conn_rd.getInputStream());
                    image_rd = image_rd.getScaledInstance(jl_image.getWidth(), jl_image.getHeight(), Image.SCALE_SMOOTH);
                    jl_image.setIcon(new ImageIcon(image_rd));
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }).start();

        jl2.setText("INDEGRIENTS");

        new Thread(new Runnable() {
            public void run() {
                try {
                    URL url = new URL("http://food2fork.com/api/get?key=" + Credentials.f2f_Api_key + "&rId=" + rId); // URL to Parse
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();

                    conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.4; en-US; rv:1.9.2.2) Gecko/20100316 Firefox/3.6.2");// spoofing java with firefox            
                    BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                    String inputLine, s1 = "";
                    if (conn.getResponseCode() == 200) {
                        while (true) {

                            inputLine = in.readLine();
                            if (inputLine == null) {
                                break;
                            }
                            s1 = s1 + inputLine;
                        }

                        JSONParser parser = new JSONParser();
                        JSONObject jobject = (JSONObject) parser.parse(s1);
                        JSONObject recipe = (JSONObject) jobject.get("recipe");
                        source_url = (String) recipe.get("source_url");
                        JSONArray ja = (JSONArray) recipe.get("ingredients");
                        JLabel[] jl = new JLabel[ja.size()];
                        int y = 10;

                        jPanel1.setPreferredSize(new Dimension(800, 2000));
                        for (int i = 0; i < ja.size(); i++) {
                            String temp = (String) ja.get(i);
                            indeg += (String) ja.get(i);
                            jl[i] = new JLabel();
                            jl[i].setText(temp);
                            jl[i].setBounds(20, y, 200, 30);

                            y = y + 40;
                            jPanel1.add(jl[i]);
                            jPanel1.repaint();

                        }

                        procedure = fetchString(source_url);
                        jl_desc.setText("DESCRIPTION");
                        ep_desc.setText(procedure);
                        bt_offline.setEnabled(true);

                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }).start();

//        new Thread(new Runnable() {
//            public void run() {
//                procedure = fetchString(source_url);
//                jl_desc.setText("DESCRIPTION");
//                ep_desc.setText(procedure);
//                bt_offline.setEnabled(true);
//            }
//        }).start();
        jb_desc.setVisible(false);
        this.setVisible(true);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);

    }

    public String fetchString(String sourceLink) {
        String inputLine, data = "", result = "";
        try {
            URL url_procedure = new URL(sourceLink); // URL to Parse
            HttpURLConnection conn_procedure = (HttpURLConnection) url_procedure.openConnection();

            conn_procedure.setRequestProperty("User-Agent", "Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.4; en-US; rv:1.9.2.2) Gecko/20100316 Firefox/3.6.2");// spoofing java with firefox            
            BufferedReader in = new BufferedReader(new InputStreamReader(conn_procedure.getInputStream()));

            if (conn_procedure.getResponseCode() == 200) {
                while (true) {
                    inputLine = in.readLine();
                    if (inputLine == null) {
                        break;
                    }
                    data = data + inputLine;
                }
                int start, end;
                int index = data.indexOf("<h4 class=\"panel-title\">Instructions</h4>");
                if (index == -1) {
                    result = "Data Not Available";
                    jb_desc.setVisible(true);
                    jb_desc.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            try {
                                Desktop.getDesktop().browse(new URI(source_url));
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }
                        }
                    });

                } else {
                    jb_desc.setVisible(false);
                    start = data.indexOf("<div class=\"panel-body\">", index);
                    end = data.indexOf("</div>", start);
                    result = data.substring(start, end + 6);
                }

            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return result;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jp1 = new javax.swing.JPanel();
        jl_title = new javax.swing.JLabel();
        jl_image = new javax.swing.JLabel();
        bt_like = new javax.swing.JButton();
        bt_unlike = new javax.swing.JButton();
        bt_offline = new javax.swing.JButton();
        jp_indegrients = new javax.swing.JPanel();
        jl_icon = new javax.swing.JLabel();
        jl2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jp_desc = new javax.swing.JPanel();
        jl_desc = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        ep_desc = new javax.swing.JEditorPane();
        jb_desc = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(null);

        jp1.setBackground(java.awt.Color.white);
        jp1.setBorder(new javax.swing.border.MatteBorder(null));
        jp1.setLayout(null);

        jl_title.setFont(new java.awt.Font("SansSerif", 3, 18)); // NOI18N
        jl_title.setText("title");
        jp1.add(jl_title);
        jl_title.setBounds(190, 40, 320, 30);

        jl_image.setText("image");
        jp1.add(jl_image);
        jl_image.setBounds(10, 10, 130, 90);

        bt_like.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/imgonline-com-ua-resize-8GrgbhmE22fOKlb.png"))); // NOI18N
        bt_like.setText("     Like");
        bt_like.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_likeActionPerformed(evt);
            }
        });
        jp1.add(bt_like);
        bt_like.setBounds(610, 20, 140, 40);

        bt_unlike.setText("Unlike");
        bt_unlike.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_unlikeActionPerformed(evt);
            }
        });
        jp1.add(bt_unlike);
        bt_unlike.setBounds(620, 20, 130, 40);

        bt_offline.setText("SaveOffline");
        bt_offline.setEnabled(false);
        bt_offline.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_offlineActionPerformed(evt);
            }
        });
        jp1.add(bt_offline);
        bt_offline.setBounds(970, 10, 170, 50);

        getContentPane().add(jp1);
        jp1.setBounds(12, 12, 1280, 110);

        jp_indegrients.setBackground(java.awt.Color.white);
        jp_indegrients.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jp_indegrients.setLayout(null);

        jl_icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/imgonline-com-ua-resize-YTYhp2qh9fsC1C.jpg"))); // NOI18N
        jl_icon.setText("jLabel1");
        jp_indegrients.add(jl_icon);
        jl_icon.setBounds(30, 20, 40, 30);

        jl2.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        jl2.setText("jLabel2");
        jp_indegrients.add(jl2);
        jl2.setBounds(80, 20, 410, 30);

        jPanel1.setBackground(java.awt.Color.white);
        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.setForeground(java.awt.Color.white);
        jPanel1.setLayout(null);
        jScrollPane1.setViewportView(jPanel1);

        jp_indegrients.add(jScrollPane1);
        jScrollPane1.setBounds(10, 70, 1260, 170);

        getContentPane().add(jp_indegrients);
        jp_indegrients.setBounds(10, 130, 1280, 260);

        jp_desc.setBackground(java.awt.Color.white);
        jp_desc.setBorder(new javax.swing.border.MatteBorder(null));
        jp_desc.setLayout(null);

        jl_desc.setBackground(java.awt.Color.white);
        jl_desc.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        jl_desc.setText("jLabel1");
        jp_desc.add(jl_desc);
        jl_desc.setBounds(260, 10, 350, 30);

        ep_desc.setEditable(false);
        ep_desc.setContentType("text/html"); // NOI18N
        jScrollPane2.setViewportView(ep_desc);

        jp_desc.add(jScrollPane2);
        jScrollPane2.setBounds(10, 40, 1260, 260);

        jb_desc.setFont(new java.awt.Font("Noto Sans CJK KR Medium", 0, 15)); // NOI18N
        jb_desc.setText("BROWSE");
        jb_desc.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jb_desc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jb_descActionPerformed(evt);
            }
        });
        jp_desc.add(jb_desc);
        jb_desc.setBounds(1120, 10, 100, 30);

        getContentPane().add(jp_desc);
        jp_desc.setBounds(10, 400, 1280, 310);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bt_likeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_likeActionPerformed
        try {
            FileOutputStream fos = new FileOutputStream("favorites.txt", true);
            PrintWriter pw = new PrintWriter(fos);
            pw.println("~" + rId + "~" + title + "~" + image_url + ";");
            pw.flush();
            fos.close();
            bt_like.setVisible(false);
            bt_unlike.setVisible(true);
            JOptionPane.showMessageDialog(this, "Your recipe" + title + " has been added to favourites.");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }//GEN-LAST:event_bt_likeActionPerformed

    private void bt_unlikeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_unlikeActionPerformed
        try {
            String s_unlike = "";
            String input;
            File f = new File("favorites.txt");
            FileInputStream fis = new FileInputStream(f);
            BufferedReader br = new BufferedReader(new InputStreamReader(fis));
            while (true) {
                input = br.readLine();
                if (input == null) {
                    break;
                }
                s_unlike = s_unlike + input;
            }
            f.delete();
            int start = s_unlike.indexOf("~" + rId + "~");
            int end = s_unlike.indexOf("~" + image_url + ";") + image_url.length() + 1;
            String part1 = s_unlike.substring(0, start);
            String part2 = s_unlike.substring(end + 1, s_unlike.length());
            String result = part1 + part2;
            FileOutputStream fos = new FileOutputStream("favorites.txt");
            PrintWriter pw = new PrintWriter(fos);
            pw.println(result);
            pw.flush();
            fis.close();
            fos.close();
            bt_like.setVisible(true);
            bt_unlike.setVisible(false);

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        //ALTERNATIVE METHOD FOR UNLIKE
//               try {
//            String s_unlike = "";
//            String input;
//            File f = new File("favorites.txt");
//            FileInputStream fis = new FileInputStream(f);
//            BufferedReader br = new BufferedReader(new InputStreamReader(fis));
//
//            FileOutputStream fos = new FileOutputStream("temp.txt");
//            PrintWriter pw = new PrintWriter(fos);
//            while (true) {
//
//                input = br.readLine();
//                if (input == null) {
//                    break;
//                } else if (input.contains("~" + rId + "~")) {
//
//                } else {
//                    pw.println(input);
//                }
//
//                //s_unlike = s_unlike + input;
//            }
//            pw.flush();
//            fis.close();
//            fos.close();
//            File f_del = new File("favorites.txt");
//            f.delete();
//            File f1 = new File("temp.txt");
//            File f2 = new File("favorites.txt");
//            f1.renameTo(f2);
//            bt_like.setVisible(true);
//            bt_unlike.setVisible(false);
//
//        } catch (Exception ex) {
//            ex.printStackTrace();
//        }
    }//GEN-LAST:event_bt_unlikeActionPerformed

    private void bt_offlineActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_offlineActionPerformed
        Socket sock;
        FileInputStream fis;
        InputStream is;
        FileOutputStream im_fos;

        String whole_result = generate_offline_page(indeg, procedure, title);
        //System.out.println(whole_result);
        if (procedure == "Data Not Available") {
            JOptionPane.showMessageDialog(this, "This recipe cannot be saved offline");
        } else {
            File f = new File("offline");
            if (!f.exists()) {
                f.mkdir();
            }

            File[] arr = f.listFiles();
            boolean flag = true;
            for (int i = 0; i < arr.length; i++) {
                if (arr[i].getName().equals(rId + ".html")) {
                    int r = JOptionPane.showConfirmDialog(this, "Do you want to save it again?", "Confirm", JOptionPane.YES_NO_OPTION);
                    if (r == JOptionPane.NO_OPTION) {
                        flag = false;
                    }
                }
            }

            if (flag) {

                try {
                    FileOutputStream fos = new FileOutputStream(f + File.separator + rId + ".html");
                    PrintWriter pw = new PrintWriter(fos);
                    pw.println(whole_result);
                    pw.flush();
                    fos.close();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                //loading image in save offline  page
                try {
                    URL im_url = new URL(image_url);
                    HttpURLConnection im_conn = (HttpURLConnection) im_url.openConnection();

                    im_conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.4; en-US; rv:1.9.2.2) Gecko/20100316 Firefox/3.6.2");// spoofing java with firefox            
                    is = im_conn.getInputStream();
                    im_fos = new FileOutputStream(f + File.separator + rId + ".jpg");

                    byte[] b = new byte[1000];
                    while (true) {
                        int r = is.read(b, 0, 1000);
                        if (r == -1) {
                            break;
                        }
                        im_fos.write(b, 0, r);
                    }
                    im_fos.close();
                    is.close();
                    //FileInputStream fis=new FileInputStream(f)
                } catch (Exception ex) {
                    ex.printStackTrace();
                }

                //adding entries in offline.txt
                try {
                    FileOutputStream fos_offline = new FileOutputStream(f + File.separator + "offline.txt", true);
                    PrintWriter pw_offline = new PrintWriter(fos_offline);
                    pw_offline.println("~" + rId + "~" + title + ";");
                    pw_offline.flush();
                    fos_offline.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }//GEN-LAST:event_bt_offlineActionPerformed

    private void jb_descActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jb_descActionPerformed
        try {
            Desktop.getDesktop().browse(new URI(source_url));
        } catch (Exception ex) {
            Logger.getLogger(RecipeDetails.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jb_descActionPerformed

    String generate_offline_page(String ing, String procedure, String title) {
        String offline = "<html>\n"
                + "    <head>\n"
                + "        <title>" + title + "</title>\n"
                + "      \n"
                + "    </head>\n"
                + "    <body style=\"background: #ccccff\">\n"
                + "        \n"
                + "        <div style=\"border: solid 1px black; border-radius: 5px;background: white; padding: 20px \">\n"
                + "            <img src=\"" + rId + ".jpg\" width=\"100\" height=\"100\" />\n"
                + "            \n"
                + "            <label style=\"font-style: italic; font-size: 25px; position: relative; top: -50px;left: 50px\"><b>" + title + "</b></label>\n"
                + "            \n"
                + "        </div>\n"
                + "        \n"
                + "        <div style=\"border: solid 1px black; border-radius: 5px;background: white; padding: 20px; margin-top: 10px \">\n"
                + "            <label style=\"font-size: 25px; \">Ingredients</label><br>\n" + ing
                + "                       \n"
                + "        </div>\n"
                + "        \n"
                + "        <div style=\"border: solid 1px black; border-radius: 5px;background: white; padding: 20px; margin-top: 10px \">\n"
                + "            <label style=\"font-size: 25px; \">Procedure</label><br>\n" + procedure
                + "                   \n"
                + "        </div>\n"
                + "        \n"
                + "        \n"
                + "    </body>\n"
                + "</html>\n"
                + "";

        return offline;
    }

    public static void main(String args[]) {
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RecipeDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RecipeDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RecipeDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RecipeDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                // new RecipeDetails().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bt_like;
    private javax.swing.JButton bt_offline;
    private javax.swing.JButton bt_unlike;
    private javax.swing.JEditorPane ep_desc;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton jb_desc;
    private javax.swing.JLabel jl2;
    private javax.swing.JLabel jl_desc;
    private javax.swing.JLabel jl_icon;
    private javax.swing.JLabel jl_image;
    private javax.swing.JLabel jl_title;
    private javax.swing.JPanel jp1;
    private javax.swing.JPanel jp_desc;
    private javax.swing.JPanel jp_indegrients;
    // End of variables declaration//GEN-END:variables
}
