package recipecentre;

import java.awt.Dimension;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class UserSearch extends javax.swing.JFrame {
    Thread t;
    public UserSearch() {
        this.setLayout(null);
        initComponents();
        this.setSize(770, 620);
        this.setVisible(true);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lb = new javax.swing.JLabel();
        bt = new javax.swing.JButton();
        tf = new javax.swing.JTextField();
        sp = new javax.swing.JScrollPane();
        mainPanel = new javax.swing.JPanel();
        bt_fav = new javax.swing.JButton();
        bt_viewOffline = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        lb.setFont(new java.awt.Font("URW Gothic L", 1, 18)); // NOI18N
        lb.setText("Type your Search");
        lb.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        getContentPane().add(lb);
        lb.setBounds(300, 10, 236, 27);

        bt.setText("Fetch");
        bt.setToolTipText("Click on the button to get results");
        bt.setBorder(javax.swing.BorderFactory.createEtchedBorder(null, java.awt.Color.gray));
        bt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btActionPerformed(evt);
            }
        });
        getContentPane().add(bt);
        bt.setBounds(320, 50, 110, 30);

        tf.setBackground(java.awt.Color.white);
        tf.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        getContentPane().add(tf);
        tf.setBounds(30, 50, 230, 30);

        mainPanel.setBackground(new java.awt.Color(0, 84, 128));
        mainPanel.setBorder(javax.swing.BorderFactory.createCompoundBorder());
        mainPanel.setLayout(null);
        sp.setViewportView(mainPanel);

        getContentPane().add(sp);
        sp.setBounds(20, 100, 700, 490);
        sp.getAccessibleContext().setAccessibleDescription("");

        bt_fav.setText("Favourites");
        bt_fav.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        bt_fav.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_favActionPerformed(evt);
            }
        });
        getContentPane().add(bt_fav);
        bt_fav.setBounds(540, 60, 140, 30);

        bt_viewOffline.setText("ViewOffline");
        bt_viewOffline.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_viewOfflineActionPerformed(evt);
            }
        });
        getContentPane().add(bt_viewOffline);
        bt_viewOffline.setBounds(540, 10, 140, 30);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btActionPerformed
        t=new Thread(new SearchTask());
//        t.interrupt();
//        try{
//        t.stop();
//        }
//        catch(Exception ex){
//            
//        }
        t.start();
        
    }//GEN-LAST:event_btActionPerformed

    private void bt_favActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_favActionPerformed
                File f = new File("favorites.txt");
                if(f.exists()){
                Favourites my_Fav=new Favourites();
                }
                else{
                    JOptionPane.showMessageDialog(this, "No added favourites");
                }
               
        
    }//GEN-LAST:event_bt_favActionPerformed

    private void bt_viewOfflineActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_viewOfflineActionPerformed
        new ViewOffline();
    }//GEN-LAST:event_bt_viewOfflineActionPerformed

    public class SearchTask implements Runnable {

        public void run() {
            mainPanel.removeAll();
            repaint();
            //bt.disable();
            try {
                URL url = new URL("http://food2fork.com/api/search?key=" + Credentials.f2f_Api_key + "&q=" + tf.getText()); // URL to Parse
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();

                conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.4; en-US; rv:1.9.2.2) Gecko/20100316 Firefox/3.6.2");// spoofing java with firefox            
                BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                String inputLine, s1 = "";
                if (conn.getResponseCode() == 200) {
                    while (true) {

                        inputLine = in.readLine();
                        if (inputLine == null) {
                            break;
                        }
                        s1 = s1 + inputLine;

                    }

                    JSONParser jp = new JSONParser();
                    JSONObject jobject = (JSONObject) jp.parse(s1);
                    
                    long count = (long) jobject.get("count");
                    RecipePanel2 np[] = new RecipePanel2[(int) count];
                    mainPanel.setPreferredSize(new Dimension(770, 2800));
                    int x = 10, y = 10;

                    JSONArray jarr = (JSONArray) jobject.get("recipes");
                    for (int i = 0; i < jarr.size(); i++) {
                        JSONObject jo = (JSONObject) jarr.get(i);
                        String title = (String) jo.get("title");
                        String image_url = (String) jo.get("image_url");
                        String recipe_id = (String) jo.get("recipe_id");

                        np[i] = new RecipePanel2();
                        np[i].setBounds(x, y, 210, 210);

                        np[i].lb2.setText("<html>" + title + "</html>");
                        URL url_image = new URL(image_url);
                        HttpURLConnection conn_image = (HttpURLConnection) url_image.openConnection();

                        conn_image.setRequestProperty("User-Agent", "Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.4; en-US; rv:1.9.2.2) Gecko/20100316 Firefox/3.6.2");

                        Image image = null;
                        image = ImageIO.read(conn_image.getInputStream());
                        image = image.getScaledInstance(np[i].lb1.getWidth(), np[i].lb1.getHeight(), Image.SCALE_SMOOTH);
                        np[i].lb1.setIcon(new ImageIcon(image));
                        ///Adding New Mouse Clicked Event
                        
                        np[i].addMouseListener(new MouseAdapter() {
                            public void mouseClicked(MouseEvent e) {
                                if(e.getClickCount()==2){
                                new RecipeDetails(title,image_url,recipe_id);
                                }
                            }
                        });

                        mainPanel.add(np[i]);
                        mainPanel.repaint();

                        if (x < 250) {
                            x += 230;
                        } else {
                            y += 230;
                            x = 10;
                        }
                    }
              //      bt.enable();

                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
         
        }
    }
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UserSearch.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UserSearch.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UserSearch.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UserSearch.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UserSearch().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bt;
    private javax.swing.JButton bt_fav;
    private javax.swing.JButton bt_viewOffline;
    private javax.swing.JLabel lb;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JScrollPane sp;
    private javax.swing.JTextField tf;
    // End of variables declaration//GEN-END:variables
}
