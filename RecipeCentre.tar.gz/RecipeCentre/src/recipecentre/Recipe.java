
package recipecentre;


public class Recipe {
    String rId;
    String title;
    String image_url;
    public Recipe(String rId,String title,String image_url){
        this.rId=rId;
        this.title=title;
        this.image_url=image_url;
    }
    public Recipe(String rId,String title){
        this.rId=rId;
        this.title=title;
        
    }
    
}
