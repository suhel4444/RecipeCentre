package recipecentre;

import java.awt.Dimension;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class VideoDemo extends javax.swing.JFrame {

    public VideoDemo() {
        this.setTitle("YouTube");
        initComponents();
        this.setSize(1000, 1000);
        this.setVisible(true);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lb1 = new javax.swing.JLabel();
        tf1 = new javax.swing.JTextField();
        bt1 = new javax.swing.JButton();
        sp = new javax.swing.JScrollPane();
        jPanel = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        lb1.setText("Enter your search");
        getContentPane().add(lb1);
        lb1.setBounds(60, -2, 200, 20);

        tf1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tf1ActionPerformed(evt);
            }
        });
        getContentPane().add(tf1);
        tf1.setBounds(50, 30, 140, 28);

        bt1.setText("Click");
        bt1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt1ActionPerformed(evt);
            }
        });
        getContentPane().add(bt1);
        bt1.setBounds(250, 30, 90, 30);

        jPanel.setBackground(java.awt.Color.black);
        jPanel.setBorder(new javax.swing.border.MatteBorder(null));
        jPanel.setLayout(null);
        sp.setViewportView(jPanel);

        getContentPane().add(sp);
        sp.setBounds(0, 90, 930, 510);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tf1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tf1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tf1ActionPerformed

    private void bt1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt1ActionPerformed
        new Thread(new Runnable() {
            @Override
            public void run() {
                jPanel.removeAll();
                repaint();
                try {
                    URL url = new URL("https://www.googleapis.com/youtube/v3/search?key=AIzaSyAVIgb1nVyBtg-Df0tC43LgTwn3Z2jMvl4&part=snippet&q=" + tf1.getText() + "&maxResults=5&order=viewCount&type=video"); // URL to Parse
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();

                    conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.4; en-US; rv:1.9.2.2) Gecko/20100316 Firefox/3.6.2");// spoofing java with firefox            
                    BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                    String inputLine, s1 = "";
                    if (conn.getResponseCode() == 200) {
                        while (true) {

                            inputLine = in.readLine();
                            if (inputLine == null) {
                                break;
                            }
                            s1 = s1 + inputLine;

                        }

                        JSONParser jp = new JSONParser();
                        JSONObject mainObject = (JSONObject) jp.parse(s1);
                        JSONArray items = (JSONArray) mainObject.get("items");
                        YouTubePanel rp[] = new YouTubePanel[items.size()];
                        jPanel.setPreferredSize(new Dimension(800, 2000));
                        int x = 10, y = 10;
                        for (int i = 0; i < items.size(); i++) {

                            String title, desc, videoId, image_url;
                            JSONObject singleobj = (JSONObject) items.get(i);
                            JSONObject id = (JSONObject) singleobj.get("id");
                            videoId = (String) id.get("videoId");
                           // System.out.println(videoId);
                            JSONObject snippet = (JSONObject) singleobj.get("snippet");
                            title = (String) snippet.get("title");
                            desc = (String) snippet.get("description");
                            //System.out.println(videoId);

                            image_url = "https://i.ytimg.com/vi/" + videoId + "/default.jpg";
                            //System.out.println(image_url);

                            rp[i] = new YouTubePanel();
                            rp[i].setBounds(x, y, jPanel.getWidth() - 10, 210);
                            rp[i].jl_title.setText("<html>" + title + "</html>");
                            rp[i].jl_desc.setText("<html>" + desc + "</html>");

                            URL url_image = new URL(image_url);
                            HttpURLConnection conn_image = (HttpURLConnection) url_image.openConnection();

                            conn_image.setRequestProperty("User-Agent", "Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.4; en-US; rv:1.9.2.2) Gecko/20100316 Firefox/3.6.2");

                            Image image = null;
                            image = ImageIO.read(conn_image.getInputStream());
                            image = image.getScaledInstance(rp[i].jl_image.getWidth(), rp[i].jl_image.getHeight(), Image.SCALE_SMOOTH);
                            rp[i].jl_image.setIcon(new ImageIcon(image));

                            rp[i].addMouseListener(new MouseAdapter() {
                                public void mouseClicked(MouseEvent e) {
                                    if (e.getClickCount() == 2) {
                                        //new RecipeDetails(title,image_url,recipe_id);
                                        new VideoFrame(videoId);
                                    }
                                }
                            });
                            jPanel.add(rp[i]);
                            jPanel.repaint();
                            y = y + 230;
                        }
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }).start();

    }//GEN-LAST:event_bt1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VideoDemo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VideoDemo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VideoDemo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VideoDemo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VideoDemo().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bt1;
    private javax.swing.JPanel jPanel;
    private javax.swing.JLabel lb1;
    private javax.swing.JScrollPane sp;
    private javax.swing.JTextField tf1;
    // End of variables declaration//GEN-END:variables
}
