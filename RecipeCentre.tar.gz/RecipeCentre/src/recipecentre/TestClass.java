
package recipecentre;

import com.teamdev.jxbrowser.chromium.Browser;
import com.teamdev.jxbrowser.chromium.swing.BrowserView;
import java.awt.BorderLayout;
import javax.swing.JFrame;

/**
 *
 * @author suhel
 */
public class TestClass {
    public static void main(String[] args) {

    Browser browser = new Browser();
    BrowserView view = new BrowserView(browser);
     
    JFrame frame = new JFrame();
    frame.setSize(700, 500);
    frame.setVisible(true);
     
    browser.loadURL("http://www.google.com");

}
}
