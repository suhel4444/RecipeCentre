package recipecentre;

import java.awt.Dimension;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.StringTokenizer;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

public class Favourites extends javax.swing.JFrame {

    ArrayList<Recipe> al_fav = new ArrayList<>();
    
    public Favourites() {
        this.setTitle("Favourites");
        initComponents();
        this.setVisible(true);
        this.setSize(700, 700);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        try {
            FileInputStream fis = new FileInputStream("favorites.txt");
            BufferedReader br = new BufferedReader(new InputStreamReader(fis));
            String input;
            String s_unlike = "";
            while (true) {
                input = br.readLine();
                if (input == null) {
                    break;
                }
                s_unlike = s_unlike + input;
            }
            fis.close();
            StringTokenizer st1 = new StringTokenizer(s_unlike, ";");
            while (st1.hasMoreTokens()) {
                String whole_recipe = st1.nextToken();
                StringTokenizer st2 = new StringTokenizer(whole_recipe, "~");
                String rId = st2.nextToken();
                String title = st2.nextToken();
                String image_url = st2.nextToken();
                System.out.println(" details   " + rId + "  title  " + title + " image  " + image_url);
                al_fav.add(new Recipe(rId, title, image_url));

            }
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        jp_fav.setPreferredSize(new Dimension(600, 1500));
                        int x = 10, y = 10;

                        RecipePanel2[] rp2 = new RecipePanel2[al_fav.size()];
                        for (int i = 0; i < al_fav.size(); i++) {
                            Recipe r = al_fav.get(i);

                            rp2[i] = new RecipePanel2();
                            rp2[i].setBounds(x, y, 210, 210);
                            // System.out.println(" in for   "+r.title);
                            rp2[i].lb2.setText("<html>" + r.title + "</html>");
                            //System.out.println(" in for 2 "+r.image_url);
                            URL url_image = new URL(r.image_url);
                            HttpURLConnection conn_image = (HttpURLConnection) url_image.openConnection();

                            conn_image.setRequestProperty("User-Agent", "Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.4; en-US; rv:1.9.2.2) Gecko/20100316 Firefox/3.6.2");

                            Image image = null;
                            image = ImageIO.read(conn_image.getInputStream());
                            image = image.getScaledInstance(rp2[i].getWidth(), rp2[i].getHeight(), Image.SCALE_SMOOTH);
                            rp2[i].lb1.setIcon(new ImageIcon(image));

                            jp_fav.add(rp2[i]);
                            jp_fav.repaint();

                            if (x < 250) {
                                x += 230;
                            } else {
                                y += 230;
                                x = 10;
                            }
                            
                            rp2[i].addMouseListener(new MouseAdapter() {
                                public void mouseClicked(MouseEvent e) {
                                    if (e.getClickCount() == 2) {
                                        new RecipeDetails(r.title, r.image_url, r.rId);
                                    }
                                }
                            });

                        }

                    } catch (Exception e) {

                        e.printStackTrace();
                    }

                }
            }).start();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lb_fav = new javax.swing.JLabel();
        sp_fav = new javax.swing.JScrollPane();
        jp_fav = new javax.swing.JPanel();
        bt_clear = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        lb_fav.setFont(new java.awt.Font("DejaVu Serif", 1, 18)); // NOI18N
        lb_fav.setText("My favourites");
        getContentPane().add(lb_fav);
        lb_fav.setBounds(120, 30, 230, 40);

        jp_fav.setLayout(null);
        sp_fav.setViewportView(jp_fav);

        getContentPane().add(sp_fav);
        sp_fav.setBounds(110, 80, 560, 400);

        bt_clear.setFont(new java.awt.Font("Ubuntu", 1, 15)); // NOI18N
        bt_clear.setText("ClearAll");
        bt_clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_clearActionPerformed(evt);
            }
        });
        getContentPane().add(bt_clear);
        bt_clear.setBounds(410, 40, 110, 30);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bt_clearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_clearActionPerformed
        //file delete,array delete jp_panel delete
        File f = new File("favorites.txt");
        f.delete();

        al_fav.removeAll(al_fav);
        jp_fav.removeAll();
        repaint();
    }//GEN-LAST:event_bt_clearActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Favourites.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Favourites.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Favourites.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Favourites.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Favourites().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bt_clear;
    private javax.swing.JPanel jp_fav;
    private javax.swing.JLabel lb_fav;
    private javax.swing.JScrollPane sp_fav;
    // End of variables declaration//GEN-END:variables
}
