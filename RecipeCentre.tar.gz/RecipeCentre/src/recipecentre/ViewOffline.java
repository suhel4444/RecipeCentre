package recipecentre;

import java.awt.Desktop;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;

public class ViewOffline extends javax.swing.JFrame {

    ArrayList<Recipe> al = new ArrayList<>();
    RecipeTableModel rtm = new RecipeTableModel();

    public ViewOffline() {
        initComponents();
        this.setTitle("View Offline");
        this.setSize(800, 800);
        this.setVisible(true);
        File f = new File("offline");
        try {
            FileInputStream fis = new FileInputStream(f + File.separator + "offline.txt");
            BufferedReader br = new BufferedReader(new InputStreamReader(fis));
            String inputLine, s1 = "";
            while (true) {
                inputLine = br.readLine();
                if (inputLine == null) {
                    break;
                }
                s1 = s1 + inputLine;
            }

            StringTokenizer st1 = new StringTokenizer(s1, ";");
            while (st1.hasMoreTokens()) {
                boolean check = true;
                String singleLine = st1.nextToken();
                StringTokenizer st2 = new StringTokenizer(singleLine, "~");
                String tmp_rid = st2.nextToken();//rid
                String tmp_title = st2.nextToken();//title
                for (int i = 0; i < al.size(); i++) {
                    if (al.get(i).rId.equals(tmp_rid)) {
                        check = false;
                    }
                }
                if (check) {
                    al.add(new Recipe(tmp_rid, tmp_title));
                    rtm.fireTableDataChanged();
                }
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        jt.setModel(rtm);

        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }

    class RecipeTableModel extends AbstractTableModel {

        String title[] = {"Serial No", "Recipe"};

        public String getColumnName(int index) {
            return title[index];
        }

        public int getRowCount() {
            return al.size();
        }

        @Override
        public int getColumnCount() {
            return title.length;
        }

        @Override
        public Object getValueAt(int rowIndex, int columnIndex) {
            if (columnIndex == 0) {
                return rowIndex + 1;
            } else {
                return al.get(rowIndex).title;
            }
        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jt = new javax.swing.JTable();
        bt = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jt.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jt);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(80, 10, 452, 402);

        bt.setText("Browse");
        bt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btActionPerformed(evt);
            }
        });
        getContentPane().add(bt);
        bt.setBounds(540, 280, 90, 30);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btActionPerformed
        int index = jt.getSelectedRow();
        if (index == -1) {
            JOptionPane.showMessageDialog(this, "You need to select row first");
        } else {
            
            String rId = al.get(index).rId;
            File f = new File("offline"+File.separator+rId+".html");
            try {
                Desktop.getDesktop().open(f);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }


    }//GEN-LAST:event_btActionPerformed

    /**
         * @param args the command line arguments
         */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ViewOffline.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ViewOffline.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ViewOffline.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ViewOffline.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                // new ViewOffline().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bt;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jt;
    // End of variables declaration//GEN-END:variables
}
