
package recipecentre;


public class YouTubePanel extends javax.swing.JPanel {


    public YouTubePanel() {
        initComponents();
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jl_image = new javax.swing.JLabel();
        jl_title = new javax.swing.JLabel();
        jl_desc = new javax.swing.JLabel();

        setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        setLayout(null);

        jl_image.setText("jLabel1");
        add(jl_image);
        jl_image.setBounds(40, 70, 140, 120);

        jl_title.setText("jLabel2");
        add(jl_title);
        jl_title.setBounds(290, 30, 450, 40);

        jl_desc.setText("jLabel3");
        add(jl_desc);
        jl_desc.setBounds(290, 90, 450, 120);
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JLabel jl_desc;
    public javax.swing.JLabel jl_image;
    public javax.swing.JLabel jl_title;
    // End of variables declaration//GEN-END:variables
}
